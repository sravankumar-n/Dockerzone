<?php

/**
 * Province form.
 *
 * @package    form
 * @subpackage Province
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class ProvinceForm extends BaseProvinceForm
{
  public function configure()
  {
  }
}