<?php

/**
 * ReportTo form.
 *
 * @package    form
 * @subpackage ReportTo
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class ReportToForm extends BaseReportToForm
{
  public function configure()
  {
  }
}