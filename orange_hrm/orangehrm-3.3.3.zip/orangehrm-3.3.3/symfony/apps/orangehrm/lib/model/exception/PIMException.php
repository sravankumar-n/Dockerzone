<?php
class PIMServiceException extends ServiceException
{
	
}