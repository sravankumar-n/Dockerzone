<?php

class AuthenticationServiceException extends Exception {
    
}

